function [ scenario ] = createscenario(  )
%CREATESCENARIO Summary of this function goes here
%   Detailed explanation goes here

scenario = net.ee.pfanalyzer.model.scenario.Scenario;

end

