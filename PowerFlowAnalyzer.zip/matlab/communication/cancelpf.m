
client = net.ee.pfanalyzer.io.MatpowerGUIClient;
client.cancelPowerFlow();
